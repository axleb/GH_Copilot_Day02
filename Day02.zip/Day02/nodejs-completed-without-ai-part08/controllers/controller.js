const Employee = require('../models/employee');
exports.getdefault = function(req, res){
  res.send('You are on the root route!.');
};
//
exports.aboutus=function(req, res){
  res.send('You are on the about us route.');
};
//
exports.addemployee=function(req, res){
  const employee = new Employee({
    name: req.body.name,
    age: req.body.age,
    salaried: req.body.salaried
  });
  employee.save()
  .then(function(employee){
    res.send(employee);
  }).catch(function(err){
    res.send(err.message);
    console.log(err);
  });
};
//
exports.getemployees= function(req, res){
  Employee.find({})
  .then(function(employees){
    res.send(employees);
  }).catch(function(err){
    res.send(err);
    console.log(err);
  });
};
/* 
exports.getemployees=async function(req, res){
  const employees = await Employee.find();
  res.send(employees);
};
 */