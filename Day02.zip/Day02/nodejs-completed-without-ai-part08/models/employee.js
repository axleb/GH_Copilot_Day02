
//
const URI = 'mongodb+srv://axleb:barraxle2025@cluster0.z6ixzam.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
const mongoose = require('mongoose');
mongoose.set('strictQuery', false);
//
try{
  mongoose.connect(URI, { useNewUrlParser: true, useUnifiedTopology: true });  
} catch(err){
  console.log("error trying to connect :" + err.message);
};
//
const employeeSchema = new mongoose.Schema({
  name: String,
  age: Number,
  salaried: Boolean
});
//
const Employee = mongoose.model('Employee', employeeSchema);
module.exports = Employee;
