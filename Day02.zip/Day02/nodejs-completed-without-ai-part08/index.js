//import * as dotenv from 'dotenv';
import { createRequire } from "module";
const require = createRequire(import.meta.url);
//dotenv.config();
const express = require('express');
const routes = require('./routes/routes');
const port = 8000;
const app = express();
app.use(express.json());
app.use(express.urlencoded({extended:false}));
const router = express.Router();
routes(router);
//
app.use('/', router);
//
app.listen(port, function(){
	console.log("Listening " + port);
});

