//import the app.js file
const app = require('./app');
const port = 8000;

app.listen(port, () => {
  console.log("Server is running on port 8000")
});
