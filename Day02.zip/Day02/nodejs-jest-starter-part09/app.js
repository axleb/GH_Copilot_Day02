const express = require('express');
const app = express();

app.get('/home', (req, res) => {
  res.send('Home endpoint!')
});

module.exports = app;
