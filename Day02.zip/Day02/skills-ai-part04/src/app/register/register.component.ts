import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from '../user'; // Import the User interface

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html'
})
export class RegisterComponent implements OnInit {
  registerForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[a-zA-Z]+$/)]],
      email: ['', [Validators.required, Validators.email, Validators.pattern(/^[a-zA-Z0-9._%+-]+@ss\.com$/)]],
      password: ['', Validators.required]
    }) as FormGroup & { value: User };
  }

  onSubmit(): void {
    if (this.registerForm.valid) {
      const user: User = this.registerForm.value; // Use the User interface
      const message = `User registered with Username: ${user.username}, Email: ${user.email}, and Password: ${user.password}`;
      console.log(message);
    } else {
      this.registerForm.markAllAsTouched(); // Mark all fields as touched to trigger validation messages
    }
  }
}
