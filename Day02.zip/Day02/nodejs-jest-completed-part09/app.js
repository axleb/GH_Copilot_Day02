const express = require('express');
const app = express();

app.get('/home', (req, res) => {
  res.send('Home endpoint!')
});

const addEmUp = function(x, y) {
  return x + y;
};

module.exports = {app, addEmUp};
