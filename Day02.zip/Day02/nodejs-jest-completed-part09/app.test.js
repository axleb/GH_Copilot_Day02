const request = require('supertest');
const app = require('./app');
/* 
describe('GET /home', () => {
  it('should respond with "Home endpoint!"', async () => {
    const response = await request(app).get('/home');
    expect(response.status).toBe(200);
    expect(response.text).toBe('Home endpoint!');
    expect(response.headers['content-type']).toMatch(/html/);
  });
});
 */
describe('addEmUp function', () => {
  it('should return the sum of two numbers', () => {
    const { addEmUp } = require('./app');
    expect(addEmUp(1, 2)).toBe(3);
    expect(addEmUp(-1, -1)).toBe(-2);
    expect(addEmUp(0, 0)).toBe(0);
  });
});