// filepath: /home/axle/Documents/skills-ai/postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}