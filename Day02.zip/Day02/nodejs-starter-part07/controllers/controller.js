const Employee = require('../models/employee');
exports.getdefault = function(req, res){
  res.send('You are on the root route.');
};
//
exports.aboutus=function(req, res){
  res.send('You are on the about us route.');
};
//
exports.addemployee=function(req, res){

};
//
exports.getemployees= function(req, res){

};
/* 
exports.getemployees=async function(req, res){
  const employees = await Employee.find();
  res.send(employees);
};
 */